#!/bin/bash

killall python3
killall tensorboard
